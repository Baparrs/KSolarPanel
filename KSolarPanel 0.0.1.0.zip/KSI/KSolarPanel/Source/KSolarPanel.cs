﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace KSolarPanel
{
    public class ModuleKSolarPanel : PartModule
    {
        private static double AU = 13599840256.0; // Kerbin AU
        private static Dictionary<string, float> starLuminosity = new Dictionary<string, float>();
        private static int ECID = 0; // Resource ID for ElectricCharge

        // Variables for the current panel
        private CelestialBody star = null; // The current star
        private float Luminosity = 0;      // Lum of the current star
        private ModuleDeployableSolarPanel existingSolarPanel = null; // The solar panel we're helping
        private float ECPT = 0; // EC per Timedelta - how much EC we need to produce for this fixed update
        // And some variables we'll use every fixed update
        Vector3d toStar;
        float distance = 0;
        float distAU = 0;

        // Displays the current output per second
        [KSPField(guiActive = true, guiActiveEditor = false, guiName = "EC", guiFormat = "F3", isPersistant = false)]
        public float EC =  0.0f;

        protected void FindOriginalSolarPanel()
        {
            // Find existing solar panel so we can use it's exposure calculations
            // Let the original panel do the geometry and occlusion checking
            existingSolarPanel = part.FindModuleImplementing<ModuleDeployableSolarPanel>();

            // Set the position of the local star - done in Kopernicus but is pointing to 
            // galactic core when I check (with Galactic-Neighborhood installed) and messing  
            // up occlusion and distance calculations - so set it back to local star
            existingSolarPanel.sunTransform = star.transform;
        }

        // Scan the Kopernicus config nodes and extract luminosity values
        protected void CompileStarData()
        {
            // Only need to do this once - not for each panel
            if (starLuminosity.Count == 0)
            {
                ConfigNode[] nodeLevel1 = GameDatabase.Instance.GetConfigNodes("Kopernicus");
                for (int i = 0; i < nodeLevel1.Length; i++)
                {
                    ConfigNode[] nodeLevel2 = nodeLevel1[i].GetNodes("Body");
                    for (int j = 0; j < nodeLevel2.Length; j++)
                    {
                        string bodyName = nodeLevel2[j].GetValue("name");
                        ConfigNode[] nodeLevel3 = nodeLevel2[j].GetNodes("Properties");
                        for (int k = 0; k < nodeLevel3.Length; k++)
                        {
                            string stLum = nodeLevel3[k].GetValue("starLuminosity");
                            if (stLum != null)
                            {
                                try
                                {
                                    float Lum = float.Parse(stLum);
                                    starLuminosity.Add(bodyName, Lum);
                                }
                                catch (Exception)
                                { /* Just don't add if not valid */ }
                            }
                        }
                    }
                }
            }
        }

        protected void ScanForLocalStar(CelestialBody bodyFrom)
        {
            // Scan up the herarchy looking for a CelestrialBody with a temperature >= 2000K
            // If we don't find the star in ten iterations - bail
            int Depth = 0;
            star = bodyFrom;
            while ((Depth < 10) && (star.GetTemperature(0) < 2000))
            {
                star = star.referenceBody;
                Depth++;
            }
            if ((star.GetTemperature(0) < 2000) || (star.name == "Galactic Core"))
                star = null;

            if (star != null)
            {
                if (starLuminosity.ContainsKey(star.name))
                    Luminosity = starLuminosity[star.name];
                else
                    Luminosity = 1;
            }
            else
                Luminosity = 0;
        }

        public void OnSOIChange(GameEvents.HostedFromToAction<Vessel, CelestialBody> evt)
        {
            // Event is called on all SOI changes - we only want the ones for our vessel
            if (evt.host == part.vessel)
                ScanForLocalStar(evt.to);
        }

        public void Start()
        {
            GameEvents.onVesselSOIChanged.Add(OnSOIChange);
            CompileStarData();
            ScanForLocalStar(FlightGlobals.currentMainBody);
            FindOriginalSolarPanel();
            PartResourceDefinition PRD = PartResourceLibrary.Instance.GetDefinition("ElectricCharge");
            if (PRD != null)
                ECID = PRD.id;
        }

        public void OnDestroy()
        {
            GameEvents.onVesselSOIChanged.Remove(OnSOIChange);
        }

        public void FixedUpdate()
        {
            if (star != null)
            {
                toStar = part.WCoM - star.position;
                distance = (float)toStar.magnitude;
                distAU = (float)(distance / AU);

                EC = existingSolarPanel.chargeRate * existingSolarPanel.sunAOA * Luminosity / (distAU * distAU);
                ECPT = EC * Time.deltaTime;
                part.RequestResource(ECID, -ECPT);
            }
        }

    }
}
